import pandas as pd
from reportlab.platypus import (
    SimpleDocTemplate,
    Table
)

def generate_pdf():

    df = pd.read_csv(
        "data/location_history.csv"
    )

    pdf = SimpleDocTemplate(
        "reports/location_report.pdf"
    )

    data = [df.columns.tolist()] + \
           df.values.tolist()

    table = Table(data)

    pdf.build([table])

    print("PDF Report Generated")