import pandas as pd

import streamlit as st

import folium

from streamlit_folium import st_folium

st.set_page_config(
    page_title="Vehicle Tracking Dashboard",
    layout="wide"
)

st.title(
    "IoT Vehicle Tracking & Theft Prevention"
)

try:

    df = pd.read_csv(
        "../data/location_history.csv"
    )

except:

    st.warning(
        "No tracking data available."
    )

    st.stop()

latest = df.iloc[-1]

lat = latest["Latitude"]
lon = latest["Longitude"]

status = latest["Status"]

st.metric(
    "Vehicle Status",
    status
)

st.metric(
    "Latitude",
    lat
)

st.metric(
    "Longitude",
    lon
)

map_obj = folium.Map(
    location=[lat, lon],
    zoom_start=15
)

folium.Marker(
    [lat, lon],
    tooltip="Vehicle Location"
).add_to(map_obj)

st_folium(
    map_obj,
    width=1200,
    height=500
)

st.subheader(
    "Location History"
)

st.dataframe(df)