from datetime import datetime

from python_simulation.gps_simulator import simulate_gps

from python_simulation.geofence import check_geofence

from python_simulation.alerts import theft_alert

from python_simulation.logger import (
    create_csv,
    log_data
)

from reports.generate_report import generate_pdf

create_csv()

print("Vehicle Tracking Started")
print("-" * 50)

for lat, lon in simulate_gps():

    timestamp = datetime.now()

    google_maps = (
        f"https://maps.google.com/?q={lat},{lon}"
    )

    inside_zone, distance = check_geofence(
        lat,
        lon
    )

    if inside_zone:

        status = "SAFE"

        alert = "NONE"

    else:

        status = "THEFT DETECTED"

        alert = "GEOFENCE ALERT"

        theft_alert(lat, lon)

    print(f"\nTime: {timestamp}")
    print(f"Latitude: {lat}")
    print(f"Longitude: {lon}")
    print(f"Distance: {distance:.2f} m")
    print(f"Status: {status}")
    print(f"Maps: {google_maps}")

    log_data(
        timestamp,
        lat,
        lon,
        distance,
        status,
        alert
    )

print("\nGenerating Report...")

generate_pdf()

print("Completed")