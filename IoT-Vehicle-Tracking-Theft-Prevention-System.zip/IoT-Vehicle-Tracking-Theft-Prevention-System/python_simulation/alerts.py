def theft_alert(lat, lon):

    print("\n")
    print("################################")
    print("THEFT ALERT!")
    print(f"Vehicle moved outside safe zone")
    print(f"Location: {lat}, {lon}")
    print("################################")
    print("\n")