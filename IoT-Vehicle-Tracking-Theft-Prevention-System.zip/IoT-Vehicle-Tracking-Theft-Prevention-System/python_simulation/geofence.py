from geopy.distance import geodesic

SAFE_LOCATION = (19.0760, 72.8777)

SAFE_RADIUS = 200

def check_geofence(lat, lon):

    current = (lat, lon)

    distance = geodesic(
        SAFE_LOCATION,
        current
    ).meters

    if distance > SAFE_RADIUS:
        return False, distance

    return True, distance