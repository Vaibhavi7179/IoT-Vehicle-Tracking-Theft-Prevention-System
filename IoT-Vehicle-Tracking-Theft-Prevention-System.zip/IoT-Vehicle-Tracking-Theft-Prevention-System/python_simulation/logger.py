
import csv
import os

FILE_NAME = "data/location_history.csv"

def create_csv():

    if not os.path.exists(FILE_NAME):

        with open(FILE_NAME, "w", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([
                "Timestamp",
                "Latitude",
                "Longitude",
                "Distance",
                "Status",
                "Alert"
            ])

def log_data(
    timestamp,
    lat,
    lon,
    distance,
    status,
    alert
):

    with open(FILE_NAME, "a", newline="") as file:

        writer = csv.writer(file)

        writer.writerow([
            timestamp,
            lat,
            lon,
            distance,
            status,
            alert
        ])