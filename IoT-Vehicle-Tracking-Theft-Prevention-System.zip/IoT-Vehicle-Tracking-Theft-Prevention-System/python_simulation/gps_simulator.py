import time

gps_points = [
    (19.0760, 72.8777),
    (19.0762, 72.8780),
    (19.0765, 72.8785),
    (19.0770, 72.8790),
    (19.0790, 72.8820),
    (19.0850, 72.8900)
]

def simulate_gps():
    for point in gps_points:
        yield point
        time.sleep(2)